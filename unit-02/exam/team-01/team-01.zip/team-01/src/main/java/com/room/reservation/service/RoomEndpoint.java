package com.room.reservation.service;

import java.math.BigDecimal;

import org.slf4j.LoggerFactory;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.room.reservation.dto.CancelReservationConfirmation;
import com.room.reservation.dto.CancelReservationRequest;
import com.room.reservation.dto.ReservationConfirmation;
import com.room.reservation.dto.ReservationConfirmationType;
import com.room.reservation.dto.RoomReservationRequest;

@Endpoint
public class RoomEndpoint {
	private static final String NAMESPACE_URI = "http://com.hotel";
	private static final org.slf4j.Logger logger = LoggerFactory.getLogger(RoomEndpoint.class);
	
	//Método reserveRoom
	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "roomReservationRequest")
    @ResponsePayload //responder con el método
    
    public ReservationConfirmation reserveRoom(@RequestPayload RoomReservationRequest request) {
		
		ReservationConfirmation response = new ReservationConfirmation ();
        ReservationConfirmationType confirmation = new ReservationConfirmationType();
        
        confirmation.setReservationId("123");
        confirmation.setRoomNumber("107");
        confirmation.setTotalCost(new BigDecimal("500.00"));
        confirmation.setConfirmationStatus("CONFIRMED");
        
        response.setConfirmation(confirmation);
        
        logger.debug("DEBUG - Reservation request received {}", request.getReservation().getGuestName());
        logger.info("INFO - Reservation request received {}", confirmation.getReservationId());
        
        return response; 
    }
	
	//Método cancelReservation
	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "cancelReservationRequest")
	@ResponsePayload
	public CancelReservationConfirmation cancelReservation(@RequestPayload CancelReservationRequest request) {
		
		logger.debug("DEBUG - Cancel reservation request received {}", request.getReservationId());
        logger.info("INFO - Cancel reservation request received {}", request.getReservationId());
        
	    CancelReservationConfirmation response = new CancelReservationConfirmation();
	    
	    response.setReservationId(request.getReservationId());
	    response.setStatus("CANCELLED");
	    
	    return response;
	}
}
