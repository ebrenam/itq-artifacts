package com.room.reservation.service;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.EndpointInvocationChain;
import org.springframework.ws.server.EndpointMapping;

@Component
@Order(Ordered.LOWEST_PRECEDENCE)
public class NoEndpointFoundEndpointMapping implements EndpointMapping {

    @Override
    public EndpointInvocationChain getEndpoint(MessageContext messageContext) throws Exception {
        
        throw new MappingNotFoundException("Falló la búsqueda de tu petición.");
    }
}