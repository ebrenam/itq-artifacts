//
// Este archivo ha sido generado por Eclipse Implementation of JAXB v3.0.0 
// Visite https://eclipse-ee4j.github.io/jaxb-ri 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2025.09.27 a las 10:57:14 AM CST 
//


package com.room.reservation.dto;

import jakarta.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.room.reservation.dto package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.room.reservation.dto
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RoomReservationRequest }
     * 
     */
    public RoomReservationRequest createRoomReservationRequest() {
        return new RoomReservationRequest();
    }

    /**
     * Create an instance of {@link RoomReservationRequestType }
     * 
     */
    public RoomReservationRequestType createRoomReservationRequestType() {
        return new RoomReservationRequestType();
    }

    /**
     * Create an instance of {@link ReservationConfirmation }
     * 
     */
    public ReservationConfirmation createReservationConfirmation() {
        return new ReservationConfirmation();
    }

    /**
     * Create an instance of {@link ReservationConfirmationType }
     * 
     */
    public ReservationConfirmationType createReservationConfirmationType() {
        return new ReservationConfirmationType();
    }

    /**
     * Create an instance of {@link CancelReservationRequest }
     * 
     */
    public CancelReservationRequest createCancelReservationRequest() {
        return new CancelReservationRequest();
    }

    /**
     * Create an instance of {@link CancelReservationConfirmation }
     * 
     */
    public CancelReservationConfirmation createCancelReservationConfirmation() {
        return new CancelReservationConfirmation();
    }

}
