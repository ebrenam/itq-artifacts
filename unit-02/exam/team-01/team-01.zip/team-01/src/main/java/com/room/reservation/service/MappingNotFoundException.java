package com.room.reservation.service;


public class MappingNotFoundException extends RuntimeException {
    public MappingNotFoundException(String message) {
        super(message);
    }
}
