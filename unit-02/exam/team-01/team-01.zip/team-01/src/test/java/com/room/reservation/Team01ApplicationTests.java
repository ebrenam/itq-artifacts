package com.room.reservation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Team01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
